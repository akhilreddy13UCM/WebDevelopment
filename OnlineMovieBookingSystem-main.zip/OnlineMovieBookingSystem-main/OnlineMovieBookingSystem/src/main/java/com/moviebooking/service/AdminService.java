package com.moviebooking.service;

import com.moviebooking.bean.Admin;

public interface AdminService {
public Admin AdminCheck(String email, String pwd);

}
